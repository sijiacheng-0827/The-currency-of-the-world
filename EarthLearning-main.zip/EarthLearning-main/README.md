# EarthLearning

## Deep learning for EARTH
Earthlearning will continue to be updated

## Instructor
[Xiaoping Du](http://sourcedb.radi.cas.cn/zw/zjrck/fyjy/201705/t20170502_4782100.html)
[Xuecao Li](https://clst.cau.edu.cn/art/2020/10/29/art_31196_714203.html)

<!-- ## Framework
<p align="center"><img width="100%" src="https://github.com/HaoweiGis/EarthLearning/blob/main/result/Framework.jpg" /></p> -->

## Example
<p align="center"><img width="100%" src="https://github.com/HaoweiGis/EarthLearning/blob/main/result/example.png" /></p>

## Related result
Big Earth Data in Support of the Sustainable Development Goals(2020)